# KOF-CeilingFan
Zigbee Ceiling Fan/light Controller by Home Depot (King of Fans)
